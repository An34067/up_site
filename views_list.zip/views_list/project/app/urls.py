from django.urls import path
from .views import *

urlpatterns = [
    path('books/', BookListView.as_view(), name='index'),
    path('author/<int:author_id>/', AuthorView.as_view(), name='author'),
]