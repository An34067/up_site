from django.db import models

# Create your models here.

class Author(models.Model):
    full_name = models.CharField()
    bio = models.TextField()

    class Meta:
        ordering = ['full_name']
        verbose_name = 'Автор'
        verbose_name_plural = 'Авторы'

    def __str__(self):
        return self.full_name

class Book(models.Model):
    title = models.CharField()
    description = models.TextField()
    author = models.ForeignKey(Author, on_delete=models.CASCADE, related_name='books')

    class Meta:
        ordering = ['title']
        verbose_name = 'Книга'
        verbose_name_plural = 'Книги'

    def __str__(self):
        return self.title