from django.shortcuts import render
from django.views import View
from .models import *

class MyListView(View):
    model = None
    template_name = None
    context_object_name = 'object_list'

    def get_queryset(self):
        return self.model.objects.all()

    def get(self, request, *args, **kwargs):
        return render(request, self.template_name, {
            self.context_object_name: self.get_queryset()
        })


class BookListView(MyListView):
    model = Book
    template_name = 'index.html'
    context_object_name = 'books'


class AuthorView(MyListView):
    model = Book
    template_name = 'author.html'
    context_object_name = 'books'
    def get_queryset(self):
        return Book.objects.filter(author_id=self.kwargs['author_id'])